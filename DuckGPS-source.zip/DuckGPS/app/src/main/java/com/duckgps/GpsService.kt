package com.duckgps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.AppOpsManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Enumeration
import java.util.Locale

class GpsService : Service() {

    companion object {
        const val TAG = "DuckGPS"

        const val ACTION_START = "com.duckgps.START"
        const val MODE_SENDER = 1
        const val MODE_RECEIVER = 2
        const val DEFAULT_PORT = 5555
        const val KEY_MODE = "mode"
        const val KEY_HOST = "host"
        const val KEY_PORT = "port"

        const val STATUS_ACTION = "com.duckgps.status"
        const val KEY_MSG = "msg"
    }

    private val CHANNEL_ID = "duckgps"

    private lateinit var locationManager: LocationManager
    private var running = false
    private var mode = 0
    private var socket: Socket? = null
    private var serverSocket: ServerSocket? = null
    private var worker: Thread? = null
    private var mockErrorReported = false

    @Volatile
    private var writer: PrintWriter? = null

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val w = writer ?: return
            val line = String.format(
                Locale.US, "%.6f,%.6f,%.1f,%.1f,%.1f,%.1f,%d",
                loc.latitude, loc.longitude, loc.altitude, loc.accuracy,
                loc.speed, loc.bearing, loc.time
            )
            try {
                w.println(line)
            } catch (_: Exception) {
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) stopWorker()

        mode = intent.getIntExtra(KEY_MODE, 0)
        val host = intent.getStringExtra(KEY_HOST) ?: ""
        val port = intent.getIntExtra(KEY_PORT, DEFAULT_PORT)
        mockErrorReported = false

        startForeground(
            1,
            buildNotification(if (mode == MODE_SENDER) "Starting sender..." else "Starting receiver...")
        )

        running = true
        worker = Thread {
            try {
                if (mode == MODE_SENDER) runSender(host, port)
                else runReceiver(port)
            } catch (e: Exception) {
                Log.w(TAG, "worker: ${e.message}")
            }
        }.apply {
            isDaemon = true
            start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        stopWorker()
        cleanupTestProviders()
        try {
            locationManager.removeUpdates(locationListener)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- Sender ----------

    private fun runSender(host: String, port: Int) {
        registerLocationUpdates()
        while (running) {
            try {
                publish("Connecting to $host:$port ...")
                val s = Socket()
                s.connect(InetSocketAddress(host.trim(), port), 5000)
                socket = s
                writer = PrintWriter(s.getOutputStream(), true)
                publish("Connected. Streaming GPS...")
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                while (running) {
                    reader.readLine() ?: break
                }
            } catch (e: Exception) {
                Log.w(TAG, "sender: ${e.message}")
            } finally {
                try {
                    socket?.close()
                } catch (_: Exception) {
                }
                socket = null
                writer = null
            }
            if (running) {
                publish("Disconnected. Reconnecting...")
                sleepQuiet(2000)
            }
        }
    }

    private fun registerLocationUpdates() {
        try {
            locationManager.removeUpdates(locationListener)
        } catch (_: Exception) {
        }
        for (provider in arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.FUSED_PROVIDER)) {
            try {
                locationManager.requestLocationUpdates(provider, 500L, 0f, locationListener)
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Receiver ----------

    private fun runReceiver(port: Int) {
        try {
            val ip = localIpAddress() ?: "unknown IP"
            publish("This phone: $ip:$port")
            if (!isMockLocationApp()) {
                publish("NOTICE: DuckGPS is not selected as the Mock location app yet. Open Settings > Developer options > Mock location app and pick DuckGPS.")
            }
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(port))
            serverSocket = ss
            publish("Listening on $ip:$port - waiting for sender...")
            while (running) {
                try {
                    val client = ss.accept()
                    client.keepAlive = true
                    publish("Sender connected. Mock location ACTIVE.")
                    handleClient(client)
                    publish("Sender disconnected. Waiting for a new one...")
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        } catch (e: Exception) {
            publish("Failed to listen on port $port (${e.message})")
        }
    }

    private fun handleClient(client: Socket) {
        try {
            client.soTimeout = 10000
            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            while (running && !client.isClosed) {
                val line = reader.readLine() ?: break
                if (line.isNotEmpty()) setMockLocation(line)
            }
        } catch (e: Exception) {
            Log.w(TAG, "client: ${e.message}")
        } finally {
            try {
                client.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun setMockLocation(line: String) {
        val parts = line.split(",")
        if (parts.size < 2) return
        val lat = parts[0].toDoubleOrNull() ?: return
        val lon = parts[1].toDoubleOrNull() ?: return
        if (lat < -90.0 || lat > 90.0 || lon < -180.0 || lon > 180.0) return

        try {
            ensureTestProviders()
            val g = Location(LocationManager.GPS_PROVIDER)
            g.latitude = lat
            g.longitude = lon
            g.altitude = parts.getOrNull(2)?.toDoubleOrNull() ?: 0.0
            g.accuracy = parts.getOrNull(3)?.toFloatOrNull() ?: 5.0f
            g.speed = parts.getOrNull(4)?.toFloatOrNull() ?: 0.0f
            g.bearing = parts.getOrNull(5)?.toFloatOrNull() ?: 0.0f
            g.time = parts.getOrNull(6)?.toLongOrNull() ?: System.currentTimeMillis()
            try {
                locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, g)
            } catch (_: Exception) {
            }

            val n = Location(LocationManager.NETWORK_PROVIDER)
            n.latitude = lat
            n.longitude = lon
            n.accuracy = g.accuracy
            n.time = g.time
            try {
                locationManager.setTestProviderLocation(LocationManager.NETWORK_PROVIDER, n)
            } catch (_: Exception) {
            }
        } catch (e: SecurityException) {
            if (!mockErrorReported) {
                mockErrorReported = true
                publish("ERROR: DuckGPS is not set as the Mock location app. Open Developer options > Mock location app and pick DuckGPS.")
                running = false
            }
        } catch (e: Exception) {
            Log.w(TAG, "mock: ${e.message}")
        }
    }

    private fun ensureTestProviders() {
        addTestProviderSafe(LocationManager.GPS_PROVIDER, false, true)
        addTestProviderSafe(LocationManager.NETWORK_PROVIDER, true, false)
        try {
            locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)
        } catch (_: Exception) {
        }
        try {
            locationManager.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, true)
        } catch (_: Exception) {
        }
    }

    private fun addTestProviderSafe(name: String, requiresNetwork: Boolean, requiresSatellite: Boolean) {
        try {
            locationManager.addTestProvider(
                name, requiresNetwork, requiresSatellite, false, false,
                true, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
        } catch (e: IllegalArgumentException) {
            // already a mock provider - fine
        }
    }

    private fun cleanupTestProviders() {
        try {
            locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {
        }
        try {
            locationManager.removeTestProvider(LocationManager.NETWORK_PROVIDER)
        } catch (_: Exception) {
        }
    }

    // ---------- Utils ----------

    private fun localIpAddress(): String? {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (nw in interfaces) {
            if (!nw.isUp || nw.isLoopback) continue
            val addrs: Enumeration<java.net.InetAddress> = nw.inetAddresses
            while (addrs.hasMoreElements()) {
                val a = addrs.nextElement()
                if ((a as? Inet4Address) != null && !a.isLoopbackAddress) return a.hostAddress
            }
        }
        return null
    }

    private fun isMockLocationApp(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(), packageName
                ) == AppOpsManager.MODE_ALLOWED
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }

    private fun publish(msg: String) {
        Log.i(TAG, msg)
        sendBroadcast(Intent(STATUS_ACTION).putExtra(KEY_MSG, msg))
        updateNotification(msg)
    }

    private fun sleepQuiet(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun stopWorker() {
        running = false
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        worker?.interrupt()
        try {
            worker?.join(1500)
        } catch (_: InterruptedException) {
        }
    }

    // ---------- Notifications ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "DuckGPS", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("DuckGPS")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_duck)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(1, buildNotification(text))
        } catch (_: Exception) {
        }
    }
}