package com.duckgps

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var ipInput: EditText
    private lateinit var btnSend: Button
    private lateinit var btnReceive: Button
    private lateinit var tvSenderStatus: TextView
    private lateinit var tvReceiverStatus: TextView

    private var activeMode = 0

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != GpsService.STATUS_ACTION) return
            val msg = intent.getStringExtra(GpsService.KEY_MSG) ?: return
            when (activeMode) {
                GpsService.MODE_RECEIVER -> tvReceiverStatus.text = msg
                GpsService.MODE_SENDER -> tvSenderStatus.text = msg
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ipInput = findViewById(R.id.ipInput)
        btnSend = findViewById(R.id.btnSend)
        btnReceive = findViewById(R.id.btnReceive)
        tvSenderStatus = findViewById(R.id.tvSenderStatus)
        tvReceiverStatus = findViewById(R.id.tvReceiverStatus)

        findViewById<TextView>(R.id.devHint).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Open Settings > Developer options manually", Toast.LENGTH_LONG).show()
            }
        }

        btnReceive.setOnClickListener {
            if (needPermissions()) return@setOnClickListener
            startServiceCore(GpsService.MODE_RECEIVER, "", GpsService.DEFAULT_PORT)
        }

        btnSend.setOnClickListener {
            val host = ipInput.text.toString().trim()
            if (host.isEmpty()) {
                Toast.makeText(this, "Enter the receiver's IP address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (needPermissions()) return@setOnClickListener
            startServiceCore(GpsService.MODE_SENDER, host, GpsService.DEFAULT_PORT)
        }
    }

    private fun startServiceCore(mode: Int, host: String, port: Int) {
        activeMode = mode
        if (mode == GpsService.MODE_RECEIVER) {
            tvReceiverStatus.text = "Starting receiver..."
        } else {
            tvSenderStatus.text = "Starting sender..."
        }
        val i = Intent(this, GpsService::class.java)
        i.action = GpsService.ACTION_START
        i.putExtra(GpsService.KEY_MODE, mode)
        i.putExtra(GpsService.KEY_HOST, host)
        i.putExtra(GpsService.KEY_PORT, port)
        startForegroundService(i)
    }

    private fun needPermissions(): Boolean {
        val needed = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return true
        }
        return false
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(statusReceiver, IntentFilter(GpsService.STATUS_ACTION), Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }
}